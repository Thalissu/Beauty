package com.example.beauty

class Login {
    lateinit var usuario: String
    lateinit var pass: String
    lateinit var tipo: String
    lateinit var chave: String
}

class GravarAgenda {
    lateinit var nome: String
    lateinit var data: String
    lateinit var data2: String
    lateinit var hora: String
    lateinit var hora2: String
    lateinit var produto: String
    lateinit var chave: String
}

data class DataAgenda(
    var nome: String,
    var data: String,
    var data2: String,
    var hora: String,
    var hora2: String,
    var produto: String,
    var chave: String
)
