package com.example.beauty

import android.os.Bundle
import android.text.Editable
import android.util.Log
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import java.time.LocalDate
import java.time.LocalTime

val retrofitIncluirAgenda: AgendaActivity.SolicitaIncluirAgenda = retrofit2.Retrofit
    .Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(HOST)
    .build()
    .create(AgendaActivity.SolicitaIncluirAgenda::class.java)

val retrofitExcluirAgenda: AgendaActivity.SolicitaExcluirAgenda = retrofit2.Retrofit
    .Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(HOST)
    .build()
    .create(AgendaActivity.SolicitaExcluirAgenda::class.java)

private lateinit var ListaArrayList: ArrayList<DataAgenda>

class AgendaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_agenda)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val vLista = findViewById<ListView>(R.id.ListView_Agenda)
        val vNome = findViewById<EditText>(R.id.edit_nome)
        val vData = findViewById<EditText>(R.id.edit_data)
        val vHora = findViewById<EditText>(R.id.edit_hora)
        val btIncluir = findViewById<FloatingActionButton>(R.id.btn_incluir)
        val btBusca = findViewById<FloatingActionButton>(R.id.btn_busca)
        val btFechar = findViewById<FloatingActionButton>(R.id.btn_fechar_agenda)
        val vProduto = findViewById<EditText>(R.id.edit_produto)

        // Pega data atual
        var dataAtual = LocalDate.now().toString()
        val vData1 = dataAtual.substring(8,10) +'/'+ dataAtual.substring(5,7) +'/'+ dataAtual.substring(0,4)
        vData.text = vData1.toEditable()

        // Pega a data escolhida no calendário principal do app
        vData.text = DTAG.toEditable()

        // Pega hora atual
        var horaAtual = LocalTime.now().toString()
        val vHora1 = horaAtual.substring(0,2) + ':' + horaAtual.substring(3,5)
        vHora.text = vHora1.toEditable()

        ListaArrayList = ArrayList()
        val agenda = GravarAgenda()
        agenda.nome = ""
        agenda.data = vData.text.toString()
        agenda.data2 = dataAtual.substring(6,10) + dataAtual.substring(3,5) + dataAtual.substring(0,2)
        agenda.hora = ""
        agenda.hora2 = ""
        agenda.produto = ""
        agenda.chave = "12345678901234"
        retrofitIncluirAgenda.setIncluirPedido(agenda.nome,agenda.data,agenda.data2,agenda.hora,agenda.hora2,agenda.produto,agenda.chave).enqueue(object : Callback<List<GravarAgenda>>{
            override fun onResponse(p0: Call<List<GravarAgenda>?>,p1: Response<List<GravarAgenda>?>) {
                if (p1.isSuccessful){
                    p1.body().let {
                        ListaArrayList.clear()
                        p1.body()!!.forEach {
                            if (!it.nome.equals("vazio")) {
                                val listaagenda = DataAgenda(it.nome,it.data,it.data2,it.hora,it.hora2,it.produto,it.chave)
                                ListaArrayList.add(listaagenda)
                            }
                        }
                    }
                    vLista.adapter = AdapterAgenda(this@AgendaActivity,ListaArrayList)
                    vLista.isClickable = true
                    vLista.setOnItemClickListener { _, _, position, _ ->
                        if (ListaArrayList[position].nome!="") {
                            val builder = AlertDialog.Builder(this@AgendaActivity)
                            builder.setTitle("CLIENTE: " + ListaArrayList[position].nome)
                                .setMessage("Escolha uma operação!")
                                .setPositiveButton("EXCLUIR") { _, _ ->
                                    agenda.nome = ListaArrayList[position].nome
                                    agenda.data = ListaArrayList[position].data
                                    agenda.data2 = ListaArrayList[position].data2
                                    agenda.hora = ListaArrayList[position].hora
                                    agenda.hora2 = ListaArrayList[position].hora2
                                    agenda.produto = ListaArrayList[position].produto
                                    agenda.chave = ListaArrayList[position].chave
                                    retrofitExcluirAgenda.setExcluirAgenda(agenda.nome,agenda.data,agenda.data2,agenda.hora,agenda.hora2,agenda.produto,agenda.chave).enqueue(object : Callback<List<GravarAgenda>>{
                                        override fun onResponse(p0: Call<List<GravarAgenda>?>, p1: Response<List<GravarAgenda>?>) {
                                            if (p1.isSuccessful){
                                                Toast.makeText(this@AgendaActivity, "CLIQUE EM ATUALIZAR!", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                        override fun onFailure(p0: Call<List<GravarAgenda>?>,p1: Throwable) {
                                            Log.d("[GRMix]:",p1.message.toString())
                                        }
                                    })
                                }
                                .setNegativeButton("FECHAR") { _, _ ->
                                    Toast.makeText(this@AgendaActivity, "OPERAÇÃO CANCELADA!", Toast.LENGTH_SHORT).show()
                                }
                            val alertDialog: AlertDialog = builder.create()
                            alertDialog.show()
                        } else {
                            Toast.makeText(this@AgendaActivity, "SELECIONE UMA AGENDA!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            override fun onFailure(
                p0: Call<List<GravarAgenda>?>,
                p1: Throwable
            ) {
                Log.d("[GRMix]:",p1.message.toString())
            }
        })

        btIncluir.setOnClickListener {

            dataAtual = vData.text.toString()
            horaAtual = vHora.text.toString()

            ListaArrayList = ArrayList()
            val agenda = GravarAgenda()
            agenda.nome = vNome.text.toString()
            agenda.data = vData.text.toString()
            agenda.data2 = dataAtual.substring(6,10) + dataAtual.substring(3,5) + dataAtual.substring(0,2)
            agenda.hora = vHora.text.toString()
            agenda.hora2 = horaAtual.substring(0,2) + horaAtual.substring(3,5)
            agenda.produto = vProduto.text.toString()
            agenda.chave = "12345678901234"

                retrofitIncluirAgenda.setIncluirPedido(agenda.nome,agenda.data,agenda.data2,agenda.hora,agenda.hora2,agenda.produto,agenda.chave).enqueue(object : Callback<List<GravarAgenda>>{
                    override fun onResponse(p0: Call<List<GravarAgenda>?>,p1: Response<List<GravarAgenda>?>) {
                        if (p1.isSuccessful){
                            p1.body().let {
                                ListaArrayList.clear()
                                p1.body()!!.forEach {
                                    if (!it.nome.equals("vazio")) {
                                        val listaagenda = DataAgenda(it.nome,it.data,it.data2,it.hora,it.hora2,it.produto,it.chave)
                                        ListaArrayList.add(listaagenda)
                                    }
                                }
                            }
                            vLista.adapter = AdapterAgenda(this@AgendaActivity,ListaArrayList)
                            vLista.isClickable = true
                            vLista.setOnItemClickListener { _, _, position, _ ->
                                if (ListaArrayList[position].nome!="") {
                                    val builder = AlertDialog.Builder(this@AgendaActivity)
                                    builder.setTitle("CLIENTE: " + ListaArrayList[position].nome)
                                        .setMessage("Escolha uma operação!")
                                        .setPositiveButton("EXCLUIR") { _, _ ->
                                            agenda.nome = ListaArrayList[position].nome
                                            agenda.data = ListaArrayList[position].data
                                            agenda.data2 = ListaArrayList[position].data2
                                            agenda.hora = ListaArrayList[position].hora
                                            agenda.hora2 = ListaArrayList[position].hora2
                                            agenda.produto = ListaArrayList[position].produto
                                            agenda.chave = ListaArrayList[position].chave
                                            retrofitExcluirAgenda.setExcluirAgenda(agenda.nome,agenda.data,agenda.data2,agenda.hora,agenda.hora2,agenda.produto,agenda.chave).enqueue(object : Callback<List<GravarAgenda>>{
                                                override fun onResponse(p0: Call<List<GravarAgenda>?>, p1: Response<List<GravarAgenda>?>) {
                                                    if (p1.isSuccessful){
                                                        Toast.makeText(this@AgendaActivity, "CLIQUE EM ATUALIZAR!", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                                override fun onFailure(p0: Call<List<GravarAgenda>?>,p1: Throwable) {
                                                    Log.d("[GRMix]:",p1.message.toString())
                                                }
                                            })
                                        }
                                        .setNegativeButton("FECHAR") { _, _ ->
                                            Toast.makeText(this@AgendaActivity, "OPERAÇÃO CANCELADA!", Toast.LENGTH_SHORT).show()
                                        }
                                    val alertDialog: AlertDialog = builder.create()
                                    alertDialog.show()
                                } else {
                                    Toast.makeText(this@AgendaActivity, "SELECIONE UMA AGENDA!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                    override fun onFailure(
                        p0: Call<List<GravarAgenda>?>,
                        p1: Throwable
                    ) {
                        Log.d("[GRMix]:",p1.message.toString())
                    }
                })

            // Pega data atual
            var dataAtual = LocalDate.now().toString()
            val vData1 = dataAtual.substring(8,10) +'/'+ dataAtual.substring(5,7) +'/'+ dataAtual.substring(0,4)
            vData.text = vData1.toEditable()

            // Pega a data escolhida no calendário principal do app
            vData.text = DTAG.toEditable()

            // Pega hora atual
            var horaAtual = LocalTime.now().toString()
            val vHora1 = horaAtual.substring(0,2) + ':' + horaAtual.substring(3,5)
            vHora.text = vHora1.toEditable()
        }

        btBusca.setOnClickListener {
            ListaArrayList = ArrayList()
            val agenda = GravarAgenda()
            agenda.nome = ""
            agenda.data = vData.text.toString()
            agenda.data2 = dataAtual.substring(6,10) + dataAtual.substring(3,5) + dataAtual.substring(0,2)
            agenda.hora = ""
            agenda.hora2 = ""
            agenda.produto = ""
            agenda.chave = "12345678901234"
            retrofitIncluirAgenda.setIncluirPedido(agenda.nome,agenda.data,agenda.data2,agenda.hora,agenda.hora2,agenda.produto,agenda.chave).enqueue(object : Callback<List<GravarAgenda>>{
                override fun onResponse(p0: Call<List<GravarAgenda>?>,p1: Response<List<GravarAgenda>?>) {
                    if (p1.isSuccessful){
                        p1.body().let {
                            ListaArrayList.clear()
                            p1.body()!!.forEach {
                                if (!it.nome.equals("vazio")) {
                                    val listaagenda = DataAgenda(it.nome,it.data,it.data2,it.hora,it.hora2,it.produto,it.chave)
                                    ListaArrayList.add(listaagenda)
                                }
                            }
                        }
                        vLista.adapter = AdapterAgenda(this@AgendaActivity,ListaArrayList)
                        vLista.isClickable = true
                        vLista.setOnItemClickListener { _, _, position, _ ->
                            if (ListaArrayList[position].nome!="") {
                                val builder = AlertDialog.Builder(this@AgendaActivity)
                                builder.setTitle("CLIENTE: " + ListaArrayList[position].nome)
                                    .setMessage("Escolha uma operação!")
                                    .setPositiveButton("EXCLUIR") { _, _ ->
                                        agenda.nome = ListaArrayList[position].nome
                                        agenda.data = ListaArrayList[position].data
                                        agenda.data2 = ListaArrayList[position].data2
                                        agenda.hora = ListaArrayList[position].hora
                                        agenda.hora2 = ListaArrayList[position].hora2
                                        agenda.produto = ListaArrayList[position].produto
                                        agenda.chave = ListaArrayList[position].chave
                                        retrofitExcluirAgenda.setExcluirAgenda(agenda.nome,agenda.data,agenda.data2,agenda.hora,agenda.hora2,agenda.produto,agenda.chave).enqueue(object : Callback<List<GravarAgenda>>{
                                            override fun onResponse(p0: Call<List<GravarAgenda>?>, p1: Response<List<GravarAgenda>?>) {
                                                if (p1.isSuccessful){
                                                    Toast.makeText(this@AgendaActivity, "CLIQUE EM ATUALIZAR!", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            override fun onFailure(p0: Call<List<GravarAgenda>?>,p1: Throwable) {
                                                Log.d("[GRMix]:",p1.message.toString())
                                            }
                                        })
                                    }
                                    .setNegativeButton("FECHAR") { _, _ ->
                                        Toast.makeText(this@AgendaActivity, "OPERAÇÃO CANCELADA!", Toast.LENGTH_SHORT).show()
                                    }
                                val alertDialog: AlertDialog = builder.create()
                                alertDialog.show()
                            } else {
                                Toast.makeText(this@AgendaActivity, "SELECIONE UMA AGENDA!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                override fun onFailure(
                    p0: Call<List<GravarAgenda>?>,
                    p1: Throwable
                ) {
                    Log.d("[GRMix]:",p1.message.toString())
                }
            })

            // Pega data atual
            var dataAtual = LocalDate.now().toString()
            val vData1 = dataAtual.substring(8,10) +'/'+ dataAtual.substring(5,7) +'/'+ dataAtual.substring(0,4)
            vData.text = vData1.toEditable()

            // Pega a data escolhida no calendário principal do app
            vData.text = DTAG.toEditable()

            // Pega hora atual
            var horaAtual = LocalTime.now().toString()
            val vHora1 = horaAtual.substring(0,2) + ':' + horaAtual.substring(3,5)
            vHora.text = vHora1.toEditable()
        }

        btFechar.setOnClickListener {
            finish()
        }

    }

    fun String.toEditable(): Editable =  Editable.Factory.getInstance().newEditable(this)

    interface SolicitaIncluirAgenda {
        @FormUrlEncoded
        @POST("app_kotlin_beauty/incluir.php")
        fun setIncluirPedido(
            @Field("nome") nome: String,
            @Field("data") data: String,
            @Field("data2") data2: String,
            @Field("hora") hora: String,
            @Field("hora2") hora2: String,
            @Field("produto") produto: String,
            @Field("chave") chave: String
        ) : Call<List<GravarAgenda>>
    }

    interface SolicitaExcluirAgenda {
        @FormUrlEncoded
        @POST("app_kotlin_beauty/excluir.php")
        fun setExcluirAgenda(
            @Field("nome") nome: String,
            @Field("data") data: String,
            @Field("data2") data2: String,
            @Field("hora") hora: String,
            @Field("hora2") hora2: String,
            @Field("produto") produto: String,
            @Field("chave") chave: String
        ) : Call<List<GravarAgenda>>
    }
}