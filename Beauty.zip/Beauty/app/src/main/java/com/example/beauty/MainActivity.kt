package com.example.beauty

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import java.time.LocalDate
import kotlin.jvm.java

var DTAG: String = ""
val CNPJ: String = "12345678901234"
val HOST: String = "http://www.datasoftma.com.br" // "http://10.0.0.195"

val retrofitLogin = retrofit2.Retrofit
    .Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(com.example.beauty.HOST)
    .build()
    .create(com.example.beauty.MainActivity.EnviaUsuarioLOGIN::class.java)

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val vUsuario = findViewById<EditText>(R.id.edit_usuario)
        val vSenha = findViewById<EditText>(R.id.edit_senha)
        val bEntrar = findViewById<Button>(R.id.btn_entrar)
        val bFechar = findViewById<Button>(R.id.btn_fechar)
        val bInfo = findViewById<FloatingActionButton>(R.id.btn_info)
        val vCombo = findViewById<Spinner>(R.id.host_spinner)
        val vCalendario = findViewById<CalendarView>(R.id.calendarView)

        // Data Atual
        var dataAtual = LocalDate.now().toString()
        val vData1 = dataAtual.substring(8,10) +'/'+ dataAtual.substring(5,7) +'/'+ dataAtual.substring(0,4)
        DTAG = vData1

        // Data do Calendário
        vCalendario.setOnDateChangeListener { view, year, month, dayOfMonth ->
            val vDia = dayOfMonth.toString().padStart(2,'0')
            val vMes = (month + 1).toString().padStart(2,'0')
            val vAno = year.toString().padStart(4,'0')
            DTAG = vDia +"/"+ vMes +"/"+ vAno
        }

        var arrayNomes = arrayOf("LOJA 1 - MATRIZ")
        val arrayAdapter = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayNomes)
        vCombo.adapter = arrayAdapter

        bEntrar.setOnClickListener {
            if (DTAG==""){
                Toast.makeText(this,"SELECIONE UMA DATA!", Toast.LENGTH_SHORT).show()
            } else {
                val usuario = Login()
                usuario.usuario = vUsuario.text.toString()
                usuario.pass = vSenha.text.toString()
                usuario.tipo = ""
                usuario.chave = "12345678901234"
                retrofitLogin.setUsuarioLOGIN(usuario.usuario,usuario.pass,usuario.tipo,usuario.chave).enqueue(object : Callback<Login>{
                    override fun onResponse(p0: Call<Login>, p1: Response<Login>) {
                        if (p1.isSuccessful) {
                            p1.body()?.let {
                                if (p1.body()!!.usuario=="vazio") {
                                    Toast.makeText(this@MainActivity," ACESSO NEGADO! ",Toast.LENGTH_SHORT).show()
                                } else {
                                    val intent = Intent(this@MainActivity, AgendaActivity::class.java)
                                    startActivity(intent)
                                }
                            }
                        } else {
                            // [ ERRO ]: POSSÍVEIS CAUSAS ( VERIFIQUE A VARIAVEL [HOST] ou O PARAMETRO [@Post] )
                            // VERIFIQUE A CONEXÃO WiFi ou Dados Móveis
                            Log.d("[GRMix]: HOST/@Post"," Verificar HOST e @Post ")
                        }
                    }
                    override fun onFailure(p0: Call<Login>, p1: Throwable) {
                        Log.d("[GRMix]: LOGIN", p1.toString())
                    }
                })
            }
        }

        bFechar.setOnClickListener{
            finishAffinity()
        }

        bInfo.setOnClickListener {
            val intent = Intent(this@MainActivity, InfoActivity::class.java)
            startActivity(intent)
        }
    }

    interface EnviaUsuarioLOGIN {
        @FormUrlEncoded
        @POST("app_kotlin_beauty/login.php")
        fun setUsuarioLOGIN(
            @Field("usuario") usuario: String,
            @Field("pass") pass: String,
            @Field("tipo") tipo: String,
            @Field("chave") chave: String
        ) : Call<Login>
    }
}