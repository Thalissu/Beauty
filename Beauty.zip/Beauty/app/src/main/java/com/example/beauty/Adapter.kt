package com.example.beauty

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class AdapterAgenda (private val context: Activity, private val arrayList: ArrayList<DataAgenda>): ArrayAdapter<DataAgenda>(context,R.layout.model_agenda,arrayList){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.model_agenda,null)

        val vicone: TextView = view.findViewById(R.id.icone_agenda)
        val vhora: TextView = view.findViewById(R.id.txt_hora_model)
        val vdata: TextView = view.findViewById(R.id.txt_data_model)
        val vnome: TextView = view.findViewById(R.id.txt_nome_model)
        val vproduto: TextView = view.findViewById(R.id.txt_produto_model)

        vicone.text = arrayList[position].nome.first().toString()
        vhora.text = arrayList[position].hora
        vdata.text = arrayList[position].data
        vnome.text = arrayList[position].nome
        vproduto.text = arrayList[position].produto

        return view
    }
}
